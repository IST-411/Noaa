
package noaaproject;


public class Metadata {
    private ResultSet resultset;
    

    public ResultSet getResultSet() {
        return resultset;
    }

    public void setResultSet(ResultSet resultSet) {
        this.resultset = resultSet;
    }
    
}
