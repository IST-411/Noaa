/* 
Project: L03 Group Work
Purpose Details: Connections NOAA Web Services
Course: IST 411
Author: Ahmed Metwoali, Alexa McInvaille, Elyse Swider, Ryan Waters
Date Developed: 6/03/21
Last Date Changed: 6/03/21
Revision: 1
 */
package noaaproject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class NoaaProject {
    public NoaaProject(){
        String accessToken = "jqitmMthppedosSPTdNkjxLrmiDoNPNm";
        Gson gson = new Gson();
        String response;
        HttpURLConnection connection = null;
        try
        {
            URL url = new URL("https://www.ncdc.noaa.gov/cdo-web/api/v2/datasets");
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestProperty("token",accessToken);
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(connection.getInputStream()));
            response = br.readLine();
            
            
            System.out.println("Result Set");
            System.out.println("----------");
            System.out.println("Offset %10s/n");
            System.out.println("Count %10s/n");
            System.out.println("Limit %10s/n");
            System.out.println(response + "\n");
        }
        catch (IOException ex)
        {
            System.out.println(ex);
        }
        finally
        {
            connection.disconnect();
        }
    }
}
