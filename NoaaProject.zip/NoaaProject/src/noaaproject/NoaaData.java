/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package noaaproject;

/**
 *
 * @author eswid
 */
public class NoaaData {
        private Metadata metadata;
        private Results results[];
    public Metadata getMetadata(){
        return metadata;
    }
    public void setMetadata(Metadata meta){
        this.metadata = metadata;
    }
    public Results[] getResults(){
        return results;
    }
    public void setResults(Results[] results){
        this.results = results;
    }
}