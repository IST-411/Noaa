/* 
Project: L03 Group Work
Purpose Details: Connections NOAA Web Services
Course: IST 411
Author: Ahmed Metwoali, Alexa McInvaille, Elyse Swider, Ryan Waters
Date Developed: 6/03/21
Last Date Changed: 6/03/21
Revision: 1
 */
package noaaproject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import com.google.gson.Gson;

public class Noaa {
    public static void main(String args[]){{
        String accessToken = "jqitmMthppedosSPTdNkjxLrmiDoNPNm";
        Gson gson = new Gson();
        String response;
        HttpURLConnection connection = null;
        try
        {
            URL url = new URL("https://www.ncdc.noaa.gov/cdo-web/api/v2/datasets");
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestProperty("token",accessToken);
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(connection.getInputStream()));
            response = br.readLine();
            NoaaData noaa = gson.fromJson(response, NoaaData.class);
            Metadata meta = gson.fromJson(response, Metadata.class);
            
            int count = 1;
            for (Results res : noaa.getResults())
            {
                System.out.println("Results " + count++);
                System.out.println("----------");
                System.out.printf("Uid %10s\n", res.getUid());
            }
            for (Mindate min : noaa.getResults())
            {
                System.out.println("Results " + count++);
                System.out.println("----------");
                System.out.printf("Uid %10s\n", min.getUid());
            }
        }
        catch (IOException ex)
        {
            System.out.println(ex);
        }
        finally
        {
            connection.disconnect();
        }
    }
}
